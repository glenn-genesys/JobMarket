package JobMarket

import JobSim.{mean, std, wmeanstd}

object Estimate {
  def byWeight(v: Double, w: Double) = Estimate(v, math.sqrt(1.0/w))
  
  // Alternate case constructor accepts Iterable[Numeric]
  def apply[T]( ds: Iterable[T])( implicit num: Numeric[T] ): Estimate = Estimate(mean(ds), std(ds))
  
  def apply( ds: Iterable[Estimate]): Estimate = wmeanstd(ds)
}

case class Estimate(v: Double, s: Double) {
  def w = 1.0/math.pow(s,2)
  
  override def toString = v.toString + " +/- " + s
}